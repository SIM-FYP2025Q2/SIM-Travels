const express = require("express");
const axios = require("axios");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const app = express();
const PORT = 3000;

app.use(express.json());

const APP_ID = process.env.APP_ID;
const KEY_ID = process.env.KEY_ID;
const SECRET = process.env.SECRET;


// App-level JWT with scope "app"
function generateAppJWT() {
  return jwt.sign(
    { iss: APP_ID, scope: "app" },
    SECRET,
    {
      header: { alg: "HS256", kid: KEY_ID },
      expiresIn: "1h",
    }
  );
}


// Generate JWT for user-level actions
// User-level JWT with scope "appUser"
function generateUserJWT(userId) {
  return jwt.sign(
    { scope: "appUser", userId },
    SECRET,
    {
      header: { alg: "HS256", kid: KEY_ID },
      expiresIn: "1h",
    }
  );
}

// Dummy weather function
async function getWeather(city = "Singapore") {
  return `It's 32°C and sunny today in ${city}. ☀️`;
}

app.get("/webhook", (req, res) => {
  res.status(200).send("Webhook endpoint is live");
});


// Webhook endpoint to receive events from Sunshine Conversations
app.post("/webhook", async (req, res) => {
  const event = req.body;
  const userId = event.payload?.user?.userId;

  // Only respond to user messages
  if (event.type === "message:appUser") {
    const text = event.payload?.message?.text;

    let reply = "Sorry, I didn't understand that.";
    if (text.toLowerCase().includes("weather")) {
      reply = await getWeather();
    }

    const token = generateAppJWT();

    // Send reply message to the user
    await axios.post(
      `https://api.smooch.io/v2/apps/${APP_ID}/users/${userId}/messages`,
      {
        role: "appMaker",
        type: "text",
        text: reply,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );
  }

  res.sendStatus(200);
});

app.listen(PORT, () => {
  console.log(`✅ Weather bot server running on http://localhost:${PORT}`);
});
