const jwt = require("jsonwebtoken");
require("dotenv").config();

const APP_ID = process.env.APP_ID;
const KEY_ID = process.env.KEY_ID;
const SECRET = process.env.SECRET;

function generateAppJWT() {
  const payload = {
    iss: "680dd98643546a74cacb2b88",         // issuer = your app ID
    scope: "app",        // required scope
  };

  const options = {
    algorithm: "HS256",
    expiresIn: "1h",
    header: {
      kid: "app_681a4ae8b47171b303973d7a",
    },
  };

  return jwt.sign(payload, SECRET, options);
}

const token = generateAppJWT();
console.log("🔑 Your app-level JWT token:\n");
console.log(token);

